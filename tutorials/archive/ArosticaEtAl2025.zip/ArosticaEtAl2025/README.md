# ArosticaEtAl2025: biventricular meshes and fibres

Input data of the `tutorials/solids/hyperelasticity/ArosticaEtAl2025/benchmark2`
tutorial of solids4foam, downloaded by its `Allrun`.

`benchmark2/{coarse,fine}` hold an OpenFOAM mesh (`constant/polyMesh`, with
patches `base`, `endo_lv`, `endo_rv` and `epi`) and the cell- and face-centred
fibre, sheet and sheet-normal fields (`0/f0`, `0/s0`, `0/n0`) of the idealised
biventricle of the cardiac elastodynamics benchmark:

R. Aróstica et al., "A software benchmark for cardiac elastodynamics",
Comput. Methods Appl. Mech. Engrg. 435 (2025) 117485.
<https://doi.org/10.1016/j.cma.2024.117485>

| Mesh | Tetrahedra | Points |
| --- | --- | --- |
| `coarse` | 45 304 | 11 444 |
| `fine` | 121 133 | 27 807 |

They were converted with `convertBiVMesh.py` (needs numpy and h5py) from the
files distributed with the benchmark in the cardiac-benchmark-toolkit (MIT
licence), <https://github.com/Reidmen/cardiac_benchmark_toolkit>, commit
`e8d47553cfc83eb274eba3e177de33148e7f441c`,
`data/biv_mesh_and_fibers_{coarse,fine}_p1`:

| File | SHA-256 |
| --- | --- |
| `coarse/bi_ventricular.h5` | `0711b37423ab4f87b9b8fe68e02dc8261e8df023621a61202756df008c8ddd53` |
| `coarse/fiber_directions.h5` | `8859c8bc10ec32aca97069f2bf513b31c2cacbecdfae7dfbdd3bdd99684d1d69` |
| `fine/bi_ventricular.h5` | `230e0f7c67b03066035e34fd69f8d3cd572addd9ad99f1538c3c9e11fc3ff0ef` |
| `fine/fiber_directions.h5` | `8f9f1ba8491986580a8ced7964a5eaa1b821ef2aa1201a976ed1e1764569765d` |

To regenerate, e.g. for the coarse mesh, from a clone of the toolkit:

```bash
mkdir coarse && cd coarse
python3 ../convertBiVMesh.py \
    <toolkit>/data/biv_mesh_and_fibers_coarse_p1 .
```

Prepared by Chanikya Valeti (UCD), with Claude Opus 5.5.
